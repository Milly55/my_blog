<?php
include "../part/head.php";
?>
<link rel="stylesheet" href="/resource/index.css">

<div class="top-btn-bar">
<div class="btn-box ">
    <div class="img-box con-min-width " style="background-image:url(http://localhost:8022/resource/img/stone-arch-828730_1920.jpg); "></div>
    <div class="space-box flex"> <div class="space-txt-1 flex">
        <ul class="flex">
            <li class="flex">GEOLOGIGAL.MUSEM</li>
            <li class="flex">시간을 담은 땅의 기록</li>
        </ul>
    </div>
</div>
</div> 
</div>

<div class="slide-bar">
    <div class="slider-box">
        <div><iframe width="560" height="315" src="https://www.youtube.com/embed/1M0FBPcWsog" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
        <div></div>
        <div></div>
    </div>
    <div class="slider-1"></div>
</div>
<?php
include "../part/foot.php";
?> 

