console.clear();

function MobileSideBar__toggle() {
    var $btn = $('.btn-toggle-mobile-side-bar');

    if ( $btn.hasClass('active') ) {
        $btn.removeClass('active');
        $('.menu-box').removeClass('active');
    }
    else {
        $btn.addClass('active');
        $('.menu-box').addClass('active');
    }
}

function MobileSideBar__init() {
    $('.btn-toggle-mobile-side-bar, .top-bar > .menu-bar  > .menu-box  > .toggle-box').click(MobileSideBar__toggle);
}

$(function() {
    MobileSideBar__init();
}); 