<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>지질박물관</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="/resource/common.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="/resource/common.js"></script>
</head>
<body>
    <div class="top-bar">
    <div class="btn-toggle-mobile-side-bar">
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="menu-bar ">
            <div class="home-box-1 flex">
                <ul class="flex">
                    <li class="flex"><a href="#"><i class="fas fa-home"></i> HOME</a></li>
                    <li class="flex"><a href="#"><i class="fas fa-bars"></i> SITEMAP</a></li>
                    <li class="flex"><a href="#">EN</a></li>
                    <li class="flex"><a href="#">지질과학유레카</a></li>
                </ul>
            </div>
            <div class="top-logo-box flex">
            <ul class="flex">
                <li class="flex" syle=" margin-top:-30px;"><a href="#"><img src="http://localhost:8022/resource/img/%EB%A1%9C%EA%B3%A02.png" alt=""></a></li>
                    <li class="flex"><img src="http://localhost:8022/resource/img/%EC%95%88%EB%82%B4.png" alt=""></li>
                </ul>
            </div>
            <div class="menu-box flex">
            <div class="toggle-box"><i class="fas fa-times"></i></div>
                <div class="time-box-1 flex "><img src="http://localhost:8022/resource/img/%EA%B4%80%EB%9E%8C%EC%8B%9C%EA%B0%84.png" alt="">
                <div class="time-txt">
                <ul>
                    <li><a href="#"><i class="far fa-clock"></i></a></li>
                    <li><a href="#"> 관람시간</a></li>
                    <li><a href="#"> 10:00~17:00</a></li>
                </ul> 
            </div>
        </div>
            <div class="logo-box"><img src="http://localhost:8022/resource/img/%EB%A1%9C%EA%B3%A0%20%EB%A9%94%EB%89%B4.png" alt=""></div>
            <ul class="flex">
                <li class="flex"><a href="#">소개</a></li>
                <li class="flex"><a href="#">전시</a></li>
                <li class="flex"><a href="#">참여</a></li>
                <li class="flex"><a href="#">예약</a></li>
                <li class="flex"><a href="#">알림</a></li>
            </ul>
            <div class="icon-box"><img src="http://localhost:8022/resource/img/%EB%A9%94%EB%89%B4%20%EA%B3%B5%EB%A3%A1.png" alt=""></div>
            </div>
        </div>
    </div>
    
